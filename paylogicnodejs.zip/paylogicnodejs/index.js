"use strict"
const express = require('express');
const pug = require('pug');
const bodyParser = require("body-parser"); 
const Crypto = require('crypto');



const app = express();

app.set('view engine', 'pug');
app.use(bodyParser.urlencoded({extended :false}));

app.get('/', (req, res) => {
    res.render('index', {});
});



app.post('/sendData', (req, res) => {
    
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds();

    let local = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;

    let post_elements = {};

    post_elements.dateTime = local;
    post_elements.amount = req.body.amount;
    post_elements.isMultiSettlement = req.body.isMultiSettlement;
    post_elements.custMobile = req.body.custMobile;
    post_elements.apiKey = req.body.apiKey;
    post_elements.productId = req.body.productId;
    post_elements.instrumentId = req.body.instrumentId;
    post_elements.udf5 = req.body.udf5;
    post_elements.cardType = req.body.cardType;
    post_elements.txnType = req.body.txnType;
    post_elements.udf3 = req.body.udf3;
    post_elements.udf4 = req.body.udf4;
    post_elements.udf1 = req.body.udf1;
    post_elements.type = req.body.type;
    post_elements.udf2 = req.body.udf2;
    post_elements.merchantId = req.body.merchantId;
    post_elements.cardDetails = req.body.cardDetails;
    post_elements.custMail = req.body.custMail;
    post_elements.returnURL = req.body.returnURL;
    post_elements.channelId = req.body.channelId;
    post_elements.txnId = req.body.txnId;

    let jsonrequest = JSON.stringify(post_elements);
    let encdata = encrypt(jsonrequest,req.body.apiKey);
   
    let return_elements={};

    return_elements.reqData = encdata;
    return_elements.merchantId = req.body.merchantId;
    return_elements.url = req.body.integrationtype;
	
    res.render('sendData', return_elements);
});

app.post('/response', (req, res) => {
    
    
    let encdata = req.body.respData;

    let key = "hr8er4hf9xW1tx1ah1qH6hU7vr7io7eR";
    let decrypted = decrypt(encdata,key); 

    var objectValue = JSON.parse(decrypted);


    let return_elements ={};

    return_elements.resp_message = objectValue.resp_message;
    return_elements.txn_id = objectValue.txn_id;
    return_elements.merchant_id=objectValue.merchant_id;
    return_elements.pg_ref_id=objectValue.pg_ref_id;
    return_elements.trans_status=objectValue.trans_status;
    return_elements.resp_date_time= objectValue.resp_date_time;
    return_elements.txn_amount= objectValue.txn_amount;


   res.render('response', return_elements);
});



app.listen(8009, ()=>{
    console.log('server started');
});


var encrypt = ((val,key) => {
    let IV = key.substring(0,16);
    let cipher = Crypto.createCipheriv('aes-256-cbc', key, IV);
    let encrypted = cipher.update(val, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
  });


  var decrypt = ((encrypted,key) => {
    let IV = key.substring(0,16);  
    let decipher = Crypto.createDecipheriv('aes-256-cbc', key, IV);
    let decrypted = decipher.update(encrypted, 'base64', 'utf8');
    return (decrypted + decipher.final('utf8'));
  });


